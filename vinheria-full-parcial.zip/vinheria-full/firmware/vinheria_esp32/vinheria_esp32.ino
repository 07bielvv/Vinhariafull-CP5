/*
 * ============================================================================
 *  CP5 - Vinheria Full  |  Firmware ESP32
 * ----------------------------------------------------------------------------
 *  Sensores : DHT11 (real) / DHT22 (Wokwi)  -> temperatura e umidade
 *             LDR                           -> luminosidade (0..100 %)
 *  Atuadores: LED azul (GPIO 2)             -> pisca enquanto houver anomalia
 *             Buzzer   (GPIO 18)            -> padrão sonoro diferente por anomalia
 *  Protocolo: MQTT + Ultralight 2.0 (FIWARE IoT Agent UL)
 *
 *  Tópicos (apikey = TEF):
 *    PUB  /TEF/<DEVICE_ID>/attrs    "t|23.5|h|65.0|l|40|a|temp,hum"
 *    SUB  /TEF/<DEVICE_ID>/cmd      "<DEVICE_ID>@alert|temp,hum"  ou  "...@alert|none"
 *    PUB  /TEF/<DEVICE_ID>/cmdexe   "<DEVICE_ID>@alert|OK"
 *
 *  Quem decide quando alertar é o FRONT-END (dashboard): ele compara as leituras
 *  com os triggers cadastrados e envia o comando "alert" via Orion -> IoT Agent
 *  -> MQTT. O ESP32 apenas executa: LED azul piscando + buzzer até receber "none".
 *
 *  Bibliotecas (Library Manager): "PubSubClient" (Nick O'Leary),
 *                                 "DHT sensor library" + "Adafruit Unified Sensor" (Adafruit)
 * ============================================================================
 */
#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

// ============================ CONFIGURAÇÃO ==================================
// Wokwi: SSID "Wokwi-GUEST" e senha vazia. Hardware real: sua rede Wi-Fi.
const char* WIFI_SSID   = "Wokwi-GUEST";
const char* WIFI_PASS   = "";

// IP público (ou da rede local) da VM/PC que roda o FIWARE (Mosquitto na 1883)
const char* MQTT_BROKER = "0.0.0.0";   // <-- TROCAR pelo IP do seu broker
const uint16_t MQTT_PORT = 1883;

const char* DEVICE_ID   = "vinheria001";  // igual ao ID cadastrado no dashboard
const char* API_KEY     = "TEF";          // igual ao apikey do service group

// 1 = DHT22 (simulação Wokwi)  |  0 = DHT11 (hardware do laboratório)
#define USE_DHT22 1

// LDR: 0 = mais luz => valor ADC maior (módulo Wokwi / divisor com LDR no GND)
//      1 = inverte (divisor com LDR no 3V3)
#define LDR_INVERT 0

// Pinos
const uint8_t PIN_DHT    = 15;
const uint8_t PIN_LDR    = 34;   // ADC1 (somente entrada) - funciona junto com Wi-Fi
const uint8_t PIN_BUZZER = 18;
const uint8_t PIN_LED    = 2;    // LED azul (onboard do DevKit / externo no Wokwi)

const unsigned long PUBLISH_INTERVAL_MS = 5000;
const unsigned long LED_BLINK_MS        = 300;
// ============================================================================

#if USE_DHT22
  #define DHTTYPE DHT22
#else
  #define DHTTYPE DHT11
#endif

DHT dht(PIN_DHT, DHTTYPE);
WiFiClient espClient;
PubSubClient mqtt(espClient);

char topicAttrs[64], topicCmd[64], topicCmdExe[64];

// Máscara de alertas ativos: bit0 = temperatura, bit1 = umidade, bit2 = luminosidade
enum { ALERT_TEMP = 1, ALERT_HUM = 2, ALERT_LUX = 4 };
volatile uint8_t alertMask = 0;

// ------------------------------- BUZZER -------------------------------------
// Compatível com ESP32 Arduino core 2.x e 3.x (API do LEDC mudou na 3.0)
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  void buzzInit()            { ledcAttach(PIN_BUZZER, 2000, 8); }
  void buzzTone(uint16_t f)  { ledcWriteTone(PIN_BUZZER, f); }
  void buzzStop()            { ledcWriteTone(PIN_BUZZER, 0); }
#else
  void buzzInit()            { ledcSetup(0, 2000, 8); ledcAttachPin(PIN_BUZZER, 0); }
  void buzzTone(uint16_t f)  { ledcWriteTone(0, f); }
  void buzzStop()            { ledcWriteTone(0, 0); }
#endif

// Cada anomalia tem um padrão sonoro próprio (freq em Hz, 0 = silêncio; ms)
struct Step { uint16_t freq; uint16_t ms; };
// TEMPERATURA : 2 bipes agudos
const Step PAT_TEMP[] = {{2000,150},{0,100},{2000,150},{0,100}};
// UMIDADE     : 3 bipes curtos médios
const Step PAT_HUM[]  = {{1200,80},{0,80},{1200,80},{0,80},{1200,80},{0,80}};
// LUMINOSIDADE: 1 bipe longo grave
const Step PAT_LUX[]  = {{600,500},{0,100}};

struct Pattern { const Step* steps; uint8_t n; };
const Pattern PATTERNS[3] = { {PAT_TEMP,4}, {PAT_HUM,6}, {PAT_LUX,2} };

uint8_t curType = 0, curStep = 0;
bool stepRunning = false;
unsigned long stepStart = 0, pauseUntil = 0;

uint8_t nextActiveType(uint8_t from) {
  for (uint8_t i = 1; i <= 3; i++) {
    uint8_t c = (from + i) % 3;
    if (alertMask & (1 << c)) return c;
  }
  return from;
}

void startStep(unsigned long now) {
  stepStart = now;
  stepRunning = true;
  uint16_t f = PATTERNS[curType].steps[curStep].freq;
  if (f) buzzTone(f); else buzzStop();
}

// Máquina de estados não-bloqueante: se houver várias anomalias, toca uma
// após a outra (com pausa) para que cada tipo continue distinguível.
void updateBuzzer() {
  unsigned long now = millis();
  if (alertMask == 0) {            // tudo normal -> silêncio
    if (stepRunning) { buzzStop(); stepRunning = false; }
    curStep = 0;
    return;
  }
  if (now < pauseUntil) return;    // pausa entre padrões
  if (!(alertMask & (1 << curType))) {   // tipo atual deixou de estar ativo
    buzzStop(); stepRunning = false;
    curType = nextActiveType(curType);
    curStep = 0;
  }
  if (!stepRunning) {
    curStep = 0;
    startStep(now);
  } else if (now - stepStart >= PATTERNS[curType].steps[curStep].ms) {
    curStep++;
    if (curStep >= PATTERNS[curType].n) {   // terminou o padrão
      buzzStop(); stepRunning = false;
      pauseUntil = now + 700;
      curType = nextActiveType(curType);
      return;
    }
    startStep(now);
  }
}

// -------------------------------- LED ---------------------------------------
void updateLed() {
  static unsigned long last = 0;
  static bool on = false;
  if (alertMask == 0) { digitalWrite(PIN_LED, LOW); on = false; return; }
  unsigned long now = millis();
  if (now - last >= LED_BLINK_MS) {
    last = now;
    on = !on;
    digitalWrite(PIN_LED, on);
  }
}

// ------------------------------ SENSORES ------------------------------------
int readLuminosityPercent() {
  long sum = 0;
  for (int i = 0; i < 8; i++) sum += analogRead(PIN_LDR);   // média reduz ruído
  int raw = sum / 8;                                        // 0..4095
  int pct = map(raw, 0, 4095, 0, 100);
#if LDR_INVERT
  pct = 100 - pct;
#endif
  return constrain(pct, 0, 100);
}

String alertString() {
  if (!alertMask) return "none";
  String s = "";
  if (alertMask & ALERT_TEMP) s += "temp,";
  if (alertMask & ALERT_HUM)  s += "hum,";
  if (alertMask & ALERT_LUX)  s += "lux,";
  s.remove(s.length() - 1);
  return s;
}

void publishAttrs() {
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  int   l = readLuminosityPercent();

  // Ultralight 2.0: chave|valor|chave|valor
  String payload = "";
  if (!isnan(t) && !isnan(h)) {
    payload += "t|" + String(t, 1) + "|h|" + String(h, 1) + "|";
  } else {
    Serial.println("[DHT] falha na leitura - enviando apenas luminosidade");
  }
  payload += "l|" + String(l) + "|a|" + alertString();

  mqtt.publish(topicAttrs, payload.c_str());
  Serial.printf("[MQTT] %s -> %s\n", topicAttrs, payload.c_str());
}

// ------------------------------ COMANDOS ------------------------------------
void applyAlert(String param) {
  uint8_t m = 0;
  if (param.indexOf("temp") >= 0) m |= ALERT_TEMP;
  if (param.indexOf("hum")  >= 0) m |= ALERT_HUM;
  if (param.indexOf("lux")  >= 0) m |= ALERT_LUX;
  alertMask = m;
  Serial.printf("[ALERTA] máscara=%u (%s)\n", m, alertString().c_str());
}

// Chega: "<DEVICE_ID>@alert|temp,hum"
void onMqttMessage(char* topic, byte* payload, unsigned int len) {
  String msg;
  for (unsigned int i = 0; i < len; i++) msg += (char)payload[i];
  Serial.printf("[MQTT] cmd recebido: %s\n", msg.c_str());

  String prefix = String(DEVICE_ID) + "@alert|";
  if (msg.startsWith(prefix)) {
    String param = msg.substring(prefix.length());
    param.trim();
    applyAlert(param);
    String ack = String(DEVICE_ID) + "@alert|OK";
    mqtt.publish(topicCmdExe, ack.c_str());   // confirma ao IoT Agent
    publishAttrs();                            // reflete o estado no dashboard
  }
}

// ------------------------------ CONEXÕES ------------------------------------
void connectWifi() {
  Serial.printf("[WiFi] conectando a %s ", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS, 6);
  while (WiFi.status() != WL_CONNECTED) { delay(300); Serial.print("."); }
  Serial.printf("\n[WiFi] OK IP=%s\n", WiFi.localIP().toString().c_str());
}

// Reconexão sem bloquear (LED e buzzer continuam funcionando)
void ensureMqtt() {
  static unsigned long lastTry = 0;
  if (mqtt.connected()) return;
  if (millis() - lastTry < 3000) return;
  lastTry = millis();
  Serial.print("[MQTT] conectando... ");
  String clientId = String("esp32-") + DEVICE_ID;
  if (mqtt.connect(clientId.c_str())) {
    Serial.println("OK");
    mqtt.subscribe(topicCmd);
  } else {
    Serial.printf("falhou rc=%d\n", mqtt.state());
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, LOW);
  buzzInit();
  buzzStop();
  analogReadResolution(12);
  dht.begin();

  snprintf(topicAttrs,  sizeof(topicAttrs),  "/%s/%s/attrs",  API_KEY, DEVICE_ID);
  snprintf(topicCmd,    sizeof(topicCmd),    "/%s/%s/cmd",    API_KEY, DEVICE_ID);
  snprintf(topicCmdExe, sizeof(topicCmdExe), "/%s/%s/cmdexe", API_KEY, DEVICE_ID);

  connectWifi();
  mqtt.setServer(MQTT_BROKER, MQTT_PORT);
  mqtt.setCallback(onMqttMessage);
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWifi();
  ensureMqtt();
  mqtt.loop();

  static unsigned long lastPub = 0;
  if (mqtt.connected() && millis() - lastPub >= PUBLISH_INTERVAL_MS) {
    lastPub = millis();
    publishAttrs();
  }

  updateLed();
  updateBuzzer();
}
