"""
storage.py - Camada de persistência local (SQLite).

O FIWARE guarda as *medições* (Orion = estado atual, STH-Comet/MongoDB = histórico).
Aqui guardamos apenas o que é "metadado de gestão" do dashboard:
  - devices   : nome amigável, local, tipo de vinho
  - triggers  : limites mín/máx de temperatura, umidade e luminosidade
  - alert_log : trilha de auditoria dos alertas disparados pelo front-end
"""
import sqlite3
import threading
from datetime import datetime, timezone

import config

_lock = threading.Lock()


def _conn():
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Cria as tabelas caso ainda não existam."""
    with _lock, _conn() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS devices (
                device_id   TEXT PRIMARY KEY,
                entity_name TEXT NOT NULL,
                label       TEXT NOT NULL,
                location    TEXT DEFAULT '',
                wine_type   TEXT DEFAULT 'generico',
                created_at  TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS triggers (
                device_id TEXT PRIMARY KEY REFERENCES devices(device_id) ON DELETE CASCADE,
                temp_min REAL, temp_max REAL,
                hum_min  REAL, hum_max  REAL,
                lux_min  REAL, lux_max  REAL
            );
            CREATE TABLE IF NOT EXISTS alert_log (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id TEXT NOT NULL,
                ts        TEXT NOT NULL,
                alerts    TEXT NOT NULL,
                detail    TEXT DEFAULT ''
            );
            """
        )


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ------------------------------- devices ------------------------------------
def list_devices():
    with _lock, _conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM devices ORDER BY created_at")]


def get_device(device_id):
    with _lock, _conn() as c:
        r = c.execute("SELECT * FROM devices WHERE device_id=?", (device_id,)).fetchone()
        return dict(r) if r else None


def add_device(device_id, entity_name, label, location, wine_type):
    with _lock, _conn() as c:
        c.execute(
            "INSERT INTO devices(device_id, entity_name, label, location, wine_type, created_at)"
            " VALUES (?,?,?,?,?,?)",
            (device_id, entity_name, label, location, wine_type, _now()),
        )


def update_device(device_id, label, location, wine_type):
    with _lock, _conn() as c:
        c.execute(
            "UPDATE devices SET label=?, location=?, wine_type=? WHERE device_id=?",
            (label, location, wine_type, device_id),
        )


def delete_device(device_id):
    with _lock, _conn() as c:
        c.execute("DELETE FROM triggers WHERE device_id=?", (device_id,))
        c.execute("DELETE FROM alert_log WHERE device_id=?", (device_id,))
        c.execute("DELETE FROM devices WHERE device_id=?", (device_id,))


# ------------------------------- triggers -----------------------------------
TRIGGER_FIELDS = ("temp_min", "temp_max", "hum_min", "hum_max", "lux_min", "lux_max")


def get_triggers(device_id):
    with _lock, _conn() as c:
        r = c.execute("SELECT * FROM triggers WHERE device_id=?", (device_id,)).fetchone()
        return {k: r[k] for k in TRIGGER_FIELDS} if r else None


def set_triggers(device_id, values):
    with _lock, _conn() as c:
        c.execute(
            "INSERT INTO triggers(device_id, temp_min, temp_max, hum_min, hum_max, lux_min, lux_max)"
            " VALUES (?,?,?,?,?,?,?)"
            " ON CONFLICT(device_id) DO UPDATE SET"
            " temp_min=excluded.temp_min, temp_max=excluded.temp_max,"
            " hum_min=excluded.hum_min, hum_max=excluded.hum_max,"
            " lux_min=excluded.lux_min, lux_max=excluded.lux_max",
            (device_id, *[values[k] for k in TRIGGER_FIELDS]),
        )


# ------------------------------- alert log ----------------------------------
def log_alert(device_id, alerts, detail=""):
    with _lock, _conn() as c:
        c.execute(
            "INSERT INTO alert_log(device_id, ts, alerts, detail) VALUES (?,?,?,?)",
            (device_id, _now(), alerts, detail),
        )


def get_alert_log(device_id, limit=50):
    with _lock, _conn() as c:
        rows = c.execute(
            "SELECT ts, alerts, detail FROM alert_log WHERE device_id=? ORDER BY id DESC LIMIT ?",
            (device_id, limit),
        )
        return [dict(r) for r in rows]
