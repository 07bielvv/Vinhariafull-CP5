"""
app.py - Camada de aplicação: API REST do dashboard Vinheria Full.

Também serve o front-end estático (../frontend) na mesma porta, então basta:
    pip install -r requirements.txt
    FIWARE_HOST=<ip-da-vm> python app.py
    -> http://localhost:5000

Endpoints principais (JSON):
    GET    /api/health                      status Orion / IoT Agent / STH-Comet
    POST   /api/bootstrap                   cria service group + subscription (idempotente)
    GET    /api/presets                     triggers sugeridos por tipo de vinho
    GET    /api/devices?with_latest=1       lista dispositivos (+ última leitura e triggers)
    POST   /api/devices                     cadastra dispositivo (IoT Agent + SQLite)
    PUT    /api/devices/<id>                edita nome/local/tipo de vinho
    DELETE /api/devices/<id>                remove dispositivo
    GET    /api/devices/<id>/latest         leitura atual (Orion)
    GET    /api/devices/<id>/history        histórico (STH-Comet :8666), ?lastN=50
    GET    /api/devices/<id>/triggers       limites configurados
    PUT    /api/devices/<id>/triggers       ajusta limites
    POST   /api/devices/<id>/alert          dispara/limpa alerta (LED azul + buzzer no ESP32)
    GET    /api/devices/<id>/alert-log      histórico de alertas
"""
import os
import re

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

import config
import fiware_client as fw
import storage

FRONTEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend"))

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")
CORS(app)

ID_RE = re.compile(r"^[A-Za-z0-9_-]{3,32}$")
VALID_ALERTS = {"temp", "hum", "lux"}


# ------------------------------ helpers -------------------------------------
def err(msg, code=400):
    return jsonify({"error": msg}), code


@app.errorhandler(fw.FiwareError)
def handle_fiware_error(e):
    # Falha em um componente FIWARE => 502 Bad Gateway com a causa para o front-end exibir.
    return err(str(e), 502)


def validate_triggers(data):
    """Converte para float e garante mín < máx em cada grandeza."""
    out = {}
    for k in storage.TRIGGER_FIELDS:
        try:
            out[k] = float(data[k])
        except (KeyError, TypeError, ValueError):
            raise ValueError(f"Campo '{k}' ausente ou não numérico")
    for pre, name in (("temp", "Temperatura"), ("hum", "Umidade"), ("lux", "Luminosidade")):
        if out[f"{pre}_min"] >= out[f"{pre}_max"]:
            raise ValueError(f"{name}: o mínimo deve ser menor que o máximo")
    for pre in ("hum", "lux"):
        if not (0 <= out[f"{pre}_min"] and out[f"{pre}_max"] <= 100):
            raise ValueError("Umidade e luminosidade devem estar entre 0 e 100 %")
    return out


def device_view(d, with_latest=False):
    d = dict(d)
    d["triggers"] = storage.get_triggers(d["device_id"])
    if with_latest:
        try:
            d["latest"] = fw.latest(d["device_id"])
        except fw.FiwareError:
            d["latest"] = None
    return d


# ------------------------------ front-end -----------------------------------
@app.get("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


# ------------------------------ infra ---------------------------------------
@app.get("/api/health")
def api_health():
    return jsonify(fw.health())


@app.post("/api/bootstrap")
def api_bootstrap():
    return jsonify(fw.bootstrap())


@app.get("/api/presets")
def api_presets():
    return jsonify(config.PRESETS)


# ------------------------------ devices (CRUD) ------------------------------
@app.get("/api/devices")
def api_devices():
    with_latest = request.args.get("with_latest") == "1"
    return jsonify([device_view(d, with_latest) for d in storage.list_devices()])


@app.post("/api/devices")
def api_device_create():
    data = request.get_json(silent=True) or {}
    device_id = (data.get("device_id") or "").strip()
    label = (data.get("label") or "").strip()
    location = (data.get("location") or "").strip()
    wine = data.get("wine_type") or config.DEFAULT_PRESET
    if not ID_RE.match(device_id):
        return err("ID inválido: use 3-32 caracteres (letras, números, _ ou -). "
                   "Deve ser o mesmo DEVICE_ID do firmware.")
    if not label:
        return err("Informe um nome para a vinheria")
    if wine not in config.PRESETS:
        return err("Tipo de vinho inválido")
    if storage.get_device(device_id):
        return err("Já existe um dispositivo com esse ID", 409)

    # 1) garante service group + subscription  2) provisiona no IoT Agent  3) salva local
    fw.bootstrap()
    fw.provision_device(device_id, label, location)
    storage.add_device(device_id, fw.entity_name_for(device_id), label, location, wine)
    storage.set_triggers(device_id, config.PRESETS[wine])
    return jsonify(device_view(storage.get_device(device_id))), 201


@app.put("/api/devices/<device_id>")
def api_device_update(device_id):
    d = storage.get_device(device_id)
    if not d:
        return err("Dispositivo não encontrado", 404)
    data = request.get_json(silent=True) or {}
    label = (data.get("label") or d["label"]).strip()
    location = (data.get("location") if data.get("location") is not None else d["location"]).strip()
    wine = data.get("wine_type") or d["wine_type"]
    if wine not in config.PRESETS:
        return err("Tipo de vinho inválido")
    storage.update_device(device_id, label, location, wine)
    return jsonify(device_view(storage.get_device(device_id)))


@app.delete("/api/devices/<device_id>")
def api_device_delete(device_id):
    if not storage.get_device(device_id):
        return err("Dispositivo não encontrado", 404)
    fw.delete_device(device_id)
    storage.delete_device(device_id)
    return "", 204


# ------------------------------ dados ---------------------------------------
@app.get("/api/devices/<device_id>/latest")
def api_latest(device_id):
    if not storage.get_device(device_id):
        return err("Dispositivo não encontrado", 404)
    return jsonify(fw.latest(device_id))


@app.get("/api/devices/<device_id>/history")
def api_history(device_id):
    if not storage.get_device(device_id):
        return err("Dispositivo não encontrado", 404)
    try:
        last_n = max(1, min(int(request.args.get("lastN", 50)), 500))
    except ValueError:
        return err("lastN inválido")
    return jsonify({
        "temperature": fw.history(device_id, "temperature", last_n),
        "humidity": fw.history(device_id, "humidity", last_n),
        "luminosity": fw.history(device_id, "luminosity", last_n),
    })


# ------------------------------ triggers ------------------------------------
@app.get("/api/devices/<device_id>/triggers")
def api_triggers_get(device_id):
    if not storage.get_device(device_id):
        return err("Dispositivo não encontrado", 404)
    return jsonify(storage.get_triggers(device_id))


@app.put("/api/devices/<device_id>/triggers")
def api_triggers_put(device_id):
    if not storage.get_device(device_id):
        return err("Dispositivo não encontrado", 404)
    try:
        values = validate_triggers(request.get_json(silent=True) or {})
    except ValueError as e:
        return err(str(e))
    storage.set_triggers(device_id, values)
    return jsonify(values)


# ------------------------------ alertas -------------------------------------
@app.post("/api/devices/<device_id>/alert")
def api_alert(device_id):
    """
    Chamado pelo FRONT-END quando ele detecta valor fora dos triggers (ou voltando ao normal).
    Body: {"alerts": ["temp","hum","lux"], "detail": "texto opcional"}
    Lista vazia => normalizado: o ESP32 apaga o LED azul e silencia o buzzer.
    """
    if not storage.get_device(device_id):
        return err("Dispositivo não encontrado", 404)
    data = request.get_json(silent=True) or {}
    alerts = data.get("alerts") or []
    if not isinstance(alerts, list) or not set(alerts) <= VALID_ALERTS:
        return err("alerts deve ser lista com valores de: temp, hum, lux")
    alerts = [a for a in ("temp", "hum", "lux") if a in alerts]  # ordem estável
    value = fw.send_alert(device_id, alerts)
    storage.log_alert(device_id, value, (data.get("detail") or "")[:200])
    return jsonify({"sent": value})


@app.get("/api/devices/<device_id>/alert-log")
def api_alert_log(device_id):
    if not storage.get_device(device_id):
        return err("Dispositivo não encontrado", 404)
    return jsonify(storage.get_alert_log(device_id))


if __name__ == "__main__":
    storage.init_db()
    try:
        print("[bootstrap]", fw.bootstrap())
    except fw.FiwareError as e:
        print(f"[aviso] FIWARE ainda indisponível ({e}). Será tentado ao cadastrar o 1º dispositivo.")
    app.run(host=config.HOST, port=config.PORT, debug=False)
