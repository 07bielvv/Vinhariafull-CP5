"""
fiware_client.py - Camada de integração com a plataforma FIWARE.

  IoT Agent UL (4041)  -> provisionamento de service group e dispositivos
  Orion (1026)         -> estado atual da entidade + envio de comandos
  STH-Comet (8666)     -> histórico de séries temporais (consumido pelos gráficos)

Fluxo de dados:
  ESP32 --MQTT/UL--> IoT Agent --NGSIv2--> Orion --subscription--> STH-Comet --> MongoDB
"""
import requests

import config


class FiwareError(Exception):
    """Erro ao falar com algum componente FIWARE (convertido em HTTP 502)."""


def _headers(json_body=False):
    h = {
        "fiware-service": config.FIWARE_SERVICE,
        "fiware-servicepath": config.FIWARE_SERVICEPATH,
    }
    if json_body:
        h["Content-Type"] = "application/json"
    return h


def _request(method, url, ok=(200, 201, 204), **kw):
    try:
        r = requests.request(method, url, timeout=config.HTTP_TIMEOUT, **kw)
    except requests.RequestException as e:
        raise FiwareError(f"Falha de rede em {url}: {e}") from e
    if r.status_code not in ok:
        raise FiwareError(f"{method} {url} -> HTTP {r.status_code}: {r.text[:300]}")
    return r


# ------------------------------ nomes ---------------------------------------
def entity_name_for(device_id):
    return f"{config.ENTITY_PREFIX}{device_id}"


# ------------------------------ bootstrap -----------------------------------
def ensure_service_group():
    """Registra o apikey (TEF) no IoT Agent - necessário para o tópico MQTT /TEF/<id>/attrs."""
    r = _request("GET", f"{config.IOTA_NORTH_URL}/iot/services", headers=_headers())
    for s in r.json().get("services", []):
        if s.get("apikey") == config.API_KEY:
            return False
    body = {
        "services": [
            {
                "apikey": config.API_KEY,
                "cbroker": config.ORION_INTERNAL,
                "entity_type": config.ENTITY_TYPE,
                "resource": "",
            }
        ]
    }
    _request("POST", f"{config.IOTA_NORTH_URL}/iot/services", headers=_headers(True), json=body)
    return True


SUB_DESCRIPTION = "Vinheria Full - histórico no STH-Comet"


def ensure_subscription():
    """Cria (uma única vez) a assinatura Orion -> STH-Comet para todas as vinherias."""
    r = _request("GET", f"{config.ORION_URL}/v2/subscriptions", headers=_headers())
    for s in r.json():
        if s.get("description") == SUB_DESCRIPTION:
            return False
    body = {
        "description": SUB_DESCRIPTION,
        "subject": {
            "entities": [{"idPattern": ".*", "type": config.ENTITY_TYPE}],
            "condition": {"attrs": ["temperature", "humidity", "luminosity", "alerts"]},
        },
        "notification": {
            "http": {"url": config.STH_INTERNAL_NOTIFY},
            "attrs": ["temperature", "humidity", "luminosity", "alerts"],
            "attrsFormat": "legacy",  # formato que o STH-Comet espera
        },
        "throttling": 0,
    }
    _request("POST", f"{config.ORION_URL}/v2/subscriptions", headers=_headers(True), json=body)
    return True


def bootstrap():
    return {"service_group_created": ensure_service_group(),
            "subscription_created": ensure_subscription()}


# ------------------------------ dispositivos --------------------------------
def provision_device(device_id, label, location):
    body = {
        "devices": [
            {
                "device_id": device_id,
                "entity_name": entity_name_for(device_id),
                "entity_type": config.ENTITY_TYPE,
                "protocol": "UL20",
                "transport": "MQTT",
                "commands": [{"name": "alert", "type": "command"}],
                "attributes": [
                    {"object_id": "t", "name": "temperature", "type": "Number"},
                    {"object_id": "h", "name": "humidity", "type": "Number"},
                    {"object_id": "l", "name": "luminosity", "type": "Number"},
                    {"object_id": "a", "name": "alerts", "type": "Text"},
                ],
                "static_attributes": [
                    {"name": "label", "type": "Text", "value": label},
                    {"name": "location", "type": "Text", "value": location or "-"},
                ],
            }
        ]
    }
    _request("POST", f"{config.IOTA_NORTH_URL}/iot/devices", headers=_headers(True), json=body)


def delete_device(device_id):
    """Remove do IoT Agent e a entidade do Orion (o histórico no STH permanece)."""
    _request("DELETE", f"{config.IOTA_NORTH_URL}/iot/devices/{device_id}",
             ok=(200, 204, 404), headers=_headers())
    _request("DELETE", f"{config.ORION_URL}/v2/entities/{entity_name_for(device_id)}",
             ok=(200, 204, 404), headers=_headers())


# ------------------------------ leitura -------------------------------------
def latest(device_id):
    """Estado atual (Orion). Retorna None se a entidade ainda não recebeu dados."""
    url = f"{config.ORION_URL}/v2/entities/{entity_name_for(device_id)}"
    try:
        r = requests.get(url, params={"type": config.ENTITY_TYPE, "options": "keyValues"},
                         headers=_headers(), timeout=config.HTTP_TIMEOUT)
    except requests.RequestException as e:
        raise FiwareError(f"Falha de rede no Orion: {e}") from e
    if r.status_code == 404:
        return None
    if r.status_code != 200:
        raise FiwareError(f"Orion HTTP {r.status_code}: {r.text[:200]}")
    e = r.json()
    return {
        "temperature": _num(e.get("temperature")),
        "humidity": _num(e.get("humidity")),
        "luminosity": _num(e.get("luminosity")),
        "alerts": e.get("alerts") or "none",
    }


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def history(device_id, attr, last_n=50):
    """Série histórica de um atributo via API do STH-Comet (porta 8666)."""
    url = (f"{config.STH_URL}/STH/v1/contextEntities/type/{config.ENTITY_TYPE}"
           f"/id/{entity_name_for(device_id)}/attributes/{attr}")
    try:
        r = requests.get(url, params={"lastN": last_n}, headers=_headers(),
                         timeout=config.HTTP_TIMEOUT)
    except requests.RequestException as e:
        raise FiwareError(f"Falha de rede no STH-Comet: {e}") from e
    if r.status_code == 404:
        return []  # ainda sem dados
    if r.status_code != 200:
        raise FiwareError(f"STH-Comet HTTP {r.status_code}: {r.text[:200]}")
    try:
        values = r.json()["contextResponses"][0]["contextElement"]["attributes"][0]["values"]
    except (KeyError, IndexError, ValueError):
        return []
    out = []
    for v in values:
        val = v.get("attrValue")
        if attr != "alerts":
            val = _num(val)
            if val is None:
                continue
        out.append({"ts": v.get("recvTime"), "value": val})
    return out


# ------------------------------ comandos ------------------------------------
def send_alert(device_id, alerts):
    """
    Envia o comando 'alert' ao ESP32 (Orion -> IoT Agent -> MQTT /TEF/<id>/cmd).
    alerts: lista com 'temp', 'hum', 'lux'  (vazia = desligar LED/buzzer).
    """
    value = ",".join(alerts) if alerts else "none"
    body = {"alert": {"type": "command", "value": value}}
    _request("PATCH",
             f"{config.ORION_URL}/v2/entities/{entity_name_for(device_id)}/attrs",
             params={"type": config.ENTITY_TYPE}, headers=_headers(True), json=body)
    return value


def health():
    """Ping nos três componentes usados pelo dashboard."""
    checks = {
        "orion": f"{config.ORION_URL}/version",
        "iot_agent": f"{config.IOTA_NORTH_URL}/iot/about",
        "sth_comet": f"{config.STH_URL}/version",
    }
    res = {}
    for name, url in checks.items():
        try:
            res[name] = requests.get(url, timeout=3).status_code == 200
        except requests.RequestException:
            res[name] = False
    return res
