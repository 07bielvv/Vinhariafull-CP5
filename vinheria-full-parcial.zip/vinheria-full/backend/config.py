"""
config.py - Configuração central do back-end.

Todos os valores podem ser sobrescritos por variáveis de ambiente, por exemplo:
    FIWARE_HOST=20.10.5.7 python app.py
"""
import os

# --- Endereço da VM/PC onde roda o docker-compose do FIWARE -----------------
FIWARE_HOST = os.getenv("FIWARE_HOST", "localhost")

# --- Portas expostas pelo docker-compose (vide ../fiware/docker-compose.yml) -
ORION_URL = os.getenv("ORION_URL", f"http://{FIWARE_HOST}:1026")
IOTA_NORTH_URL = os.getenv("IOTA_NORTH_URL", f"http://{FIWARE_HOST}:4041")
STH_URL = os.getenv("STH_URL", f"http://{FIWARE_HOST}:8666")  # STH-Comet (API 8666)

# --- URLs vistas de DENTRO da rede docker (usadas em cbroker/subscription) ---
ORION_INTERNAL = os.getenv("ORION_INTERNAL", "http://orion:1026")
STH_INTERNAL_NOTIFY = os.getenv("STH_INTERNAL_NOTIFY", "http://sth-comet:8666/notify")

# --- Multi-tenancy FIWARE ----------------------------------------------------
FIWARE_SERVICE = os.getenv("FIWARE_SERVICE", "smart")
FIWARE_SERVICEPATH = os.getenv("FIWARE_SERVICEPATH", "/")

# --- Modelo de dados ---------------------------------------------------------
API_KEY = os.getenv("API_KEY", "TEF")            # mesmo apikey do firmware
ENTITY_TYPE = os.getenv("ENTITY_TYPE", "Vinheria")
ENTITY_PREFIX = "urn:ngsi-ld:Vinheria:"

# --- Servidor web ------------------------------------------------------------
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "5000"))
DB_PATH = os.getenv("DB_PATH", os.path.join(os.path.dirname(__file__), "vinheria.db"))
HTTP_TIMEOUT = 8  # segundos

# --- Triggers padrão (adega de vinhos) ---------------------------------------
# Referência: 10-16 °C, 60-80 % UR, luz baixa (< 30 %) para preservar o vinho.
PRESETS = {
    "tinto":      {"temp_min": 14, "temp_max": 18, "hum_min": 60, "hum_max": 80, "lux_min": 0, "lux_max": 30},
    "branco":     {"temp_min": 8,  "temp_max": 12, "hum_min": 60, "hum_max": 80, "lux_min": 0, "lux_max": 30},
    "espumante":  {"temp_min": 6,  "temp_max": 10, "hum_min": 65, "hum_max": 80, "lux_min": 0, "lux_max": 25},
    "generico":   {"temp_min": 10, "temp_max": 16, "hum_min": 60, "hum_max": 80, "lux_min": 0, "lux_max": 30},
}
DEFAULT_PRESET = "generico"
